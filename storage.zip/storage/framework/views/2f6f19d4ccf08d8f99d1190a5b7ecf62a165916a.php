<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Prajwal\Desktop\Advance-Ecommerce-in-laravel-7\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>